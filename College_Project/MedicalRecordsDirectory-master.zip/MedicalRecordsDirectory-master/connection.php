<?php


$db = mysqli_connect('localhost', 'root', '', 'med_rec_dir');

/*
  try {
  $pdo = new PDO('mysql:host=localhost;dbname =  medical_records_directory', 'root', '');
  echo 'connected';
  } catch (PDOException $e) {
  exit('Database Error');
  } 
*/

?>



